extern void uart0_init(unsigned int buad);
extern void uart0_tx(unsigned char data);
extern void uart0_tx_string(unsigned char *p);
extern void config_vic_for_can1(void);
extern void delay_ms(unsigned int ms);
typedef struct CAN1_MSG
{
unsigned int id;
unsigned int byteA;
unsigned int byteB;
unsigned char rtr;
unsigned char dlc;

}CAN1;
extern void can1_init(void);
extern void can1_tx(CAN1 v);
extern void can1_rx(CAN1 *ptr);
