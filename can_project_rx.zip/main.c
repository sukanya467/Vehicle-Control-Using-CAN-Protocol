#include<lpc21xx.h>
#include"header.h"
#define LED1 (1<<17)
#define LED2 (1<<18)
#define LED3 (1<<19)
CAN1 r1;
unsigned int flag;
main()
{
IODIR0=LED1|LED2|LED3;
IOSET0=LED1|LED2|LED3;
can1_init();
uart0_init(9600);
config_vic_for_can1( );
uart0_tx_string("Receiver\r\n");	
while(1)
{
if(flag==1) {
uart0_tx_string("ISR Executed\r\n");
//l:
switch(r1.byteA&0xff)
{
//headlight on
case 0x10:
IOCLR0=LED1;
uart0_tx_string("r1\r\n");
break;

//headlight off
case 0x11:
IOSET0=LED1;
uart0_tx_string("r1\r\n");
break;

//left indicator
l1:
case 0x20:
IOSET0=LED3;
while(1)
{
IOCLR0=LED2; 
delay_ms(200);
IOSET0=LED2;
delay_ms(200);
uart0_tx_string("r2\r\n");
if(((r1.byteA&0xff)==0x21)|((r1.byteA&0xff)==0x30))
{
IOSET0=LED2;
if((r1.byteA&0xff)==0x30)
goto l;
 break;
}
if((r1.byteA&0xff)==0x10)
IOCLR0=LED1;
if((r1.byteA&0xff)==0x11)
IOSET0=LED1;
}
break;

case 0x21:
IOSET0=LED2;
uart0_tx_string("r2\r\n");
break;

//right indicator
l:
case 0x30:
IOSET0=LED2;
while(1)
{
IOCLR0=LED3; 
delay_ms(200);
IOSET0=LED3;
delay_ms(200);
uart0_tx_string("r3\r\n");
if(((r1.byteA&0xff)==0x31)|(r1.byteA&0xff)==0x20)
{
IOSET0=LED2;
if((r1.byteA&0xff)==0x20)
goto l1;
break;
}
if((r1.byteA&0xff)==0x10)
IOCLR0=LED1;
if((r1.byteA&0xff)==0x11)
IOSET0=LED1;
}
break;

case 0x31:IOSET0=LED3;
uart0_tx_string("r3\r\n");
break;
}
flag=0;
}
}
}
