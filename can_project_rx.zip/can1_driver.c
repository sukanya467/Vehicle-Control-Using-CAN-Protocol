#include <LPC21xx.H>
#include "header.h"
void can1_init(void){
	PINSEL1|=0x00014000;
	VPBDIV=1;//PCLK=60MHz
	C2MOD=1;//reset mode
	C2BTR=0x001C001D;//125Kbps baudrate
	AFMR=2;//Accept all receiving data-frames
	C2MOD=0;//release reset mode
}
extern CAN1 r1;
extern unsigned int flag;

void CAN1_Rx_Handler(void) __irq{
	r1.id=C2RID;
	r1.dlc=(C2RFS>>16)&0xF;//extract dlc
	r1.rtr=(C2RFS>>30)&1;//extract rtr
	if(r1.rtr==0){//if data-frame
		r1.byteA=C2RDA;
		r1.byteB=C2RDB;
	}
		C2CMR=(1<<2);//*release rxbuf
	flag=1;//further used in main func

	VICVectAddr=0;
}

void config_vic_for_can1(void){
	VICVectAddr3=(unsigned int)CAN1_Rx_Handler;
	VICVectCntl3=27|(1<<5);
	VICIntEnable=(1<<27);//en CAN2 Rx intr in to VIC
	C2IER=1;//en CAN1 rx intr in CAN1 peri
}

#define RBS (C2GSR&1)
void can1_rx(CAN1 *ptr){
	while(RBS==0);
	ptr->id=C2RID;
	ptr->dlc=(C2RFS>>16)&0xF;//extract dlc
	ptr->rtr=(C2RFS>>30)&1;//extract rtr
	if(ptr->rtr==0){//if data-frame
		ptr->byteA=C2RDA;
		ptr->byteB=C2RDB;
	}
	C2CMR=(1<<2);//release rxbuf
}

#define TCS ((C2GSR>>3)&1)
void can1_tx(CAN1 v){
	C2TID1=v.id;
	C2TFI1=(v.dlc<<16);//Set DLC, RTR=0, FF=0
	
	if(v.rtr==0){//if data-frame
		C2TDA1=v.byteA;
		C2TDB1=v.byteB;
	}
	else
		C2TFI1|=(1<<30);//rtr=1
	
	C2CMR=1|(1<<5);//Start Xmission & select Txbuf1
	while(((C2GSR>>3)&1)==0);
}
