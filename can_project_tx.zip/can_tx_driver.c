#include<lpc21xx.h>
#include"header.h"
void can1_init(void){
	PINSEL1|=0x00014000;
	VPBDIV=1;//PCLK=60MHz
	C2MOD=1;//reset mode
	C2BTR=0x001C001D;//125Kbps baudrate
	AFMR=2;//Accept all receiving data-frames
	C2MOD=0;//release reset mode
}
#define TCS ((C2GSR>>3)&1)
void can1_tx(CAN1 v){
C2TID1=v.id;
C2TFI1=v.dlc<<16;
if(v.rtr==0)
{
C2TDA1=v.byteA;
C2TDB1=v.byteB;
}
else
C2TFI1|=(1<<30);
C2CMR=1|(1<<5);
while(TCS==0);
}

#define RBS (C2GSR&1)
void can1_rx(CAN1 *ptr){
	while(RBS==0);
	ptr->id=C2RID;
	ptr->dlc=(C2RFS>>16)&0x0F;//extract dlc
	ptr->rtr=(C2RFS>>30)&1;//extract rtr
	if(ptr->rtr==0){//if data-frame
		ptr->byteA=C2RDA;
		ptr->byteB=C2RDB;
	}
	C2CMR=(1<<2);//release rxbuf
}

