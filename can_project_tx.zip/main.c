#include<lpc21xx.h>
#include "header.h"
#define SW1 ((IOPIN0>>14)&1)
#define SW2 ((IOPIN0>>15)&1)
#define SW3 ((IOPIN0>>16)&1)
CAN1 v1;
main()
{
unsigned char flag=0,flag1=0,flag2=0;
//VPBDIV=1;
can1_init( );
uart0_init(9600);
uart0_tx_string("transmit\r\n");
v1.rtr=0;//data frame
v1.dlc=1;
v1.byteA=0;
v1.byteB=0;

while(1)
{
if(SW1==0)
{
while(SW1==0);
delay_ms(10);
flag^=1;
v1.id=0x100;
if(flag)
{
v1.byteA=0x10;//HL ON
can1_tx(v1);
uart0_tx_string("data frame1\r\n");
}
else
{
v1.byteA=0x11;//HL OFF
can1_tx(v1);
}

}

if(SW2==0)
{
while(SW2==0);
delay_ms(10);
flag1^=1;
	v1.id=0x200;
if(flag1)
{
v1.byteA=0x20;//Left indicator ON
can1_tx(v1);
}
else
{
v1.byteA=0x21;//Left indicator OFF
can1_tx(v1);
}
uart0_tx_string("data frame2\r\n");
}
if(SW3==0)
{
	while(SW3==0);
	delay_ms(10);
	flag2^=1;
	v1.id=0x300;
	if(flag2)
	{
		v1.byteA=0x30;//Right indicator ON
		can1_tx(v1);
		}
	else
	{
		v1.byteA=0x31;//Right idicator OFF
	can1_tx(v1);
	}
	uart0_tx_string("data frame3\r\n");
}
}
}
